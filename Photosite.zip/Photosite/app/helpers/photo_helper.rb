module PhotoHelper
end
